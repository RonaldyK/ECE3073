#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include "alt_types.h"
#include "system.h"
#include "sys/alt_irq.h"
#include "altera_avalon_pio_regs.h"
#include "io.h"
#include "altera_up_avalon_accelerometer_spi.h"

// String output
char output[64];

static void sevenseg_set_hex(int hex, uint32_t segment_base_address);

void write_pixel(unsigned int addr, unsigned char color);
void draw_color_stripes();
void draw_vertical_stripes();


int main()
{
  printf("Hello from Nios II!\n");
  sevenseg_set_hex(1, SEVEN_SEG_0_BASE);
  sevenseg_set_hex(2, SEVEN_SEG_1_BASE);
  sevenseg_set_hex(3, SEVEN_SEG_2_BASE);
  sevenseg_set_hex(4, SEVEN_SEG_3_BASE);
  sevenseg_set_hex(5, SEVEN_SEG_4_BASE);
  sevenseg_set_hex(6, SEVEN_SEG_5_BASE);

  // Test VGA
  draw_vertical_stripes();

  draw_color_stripes();

  // initialize accel
  alt_up_accelerometer_spi_dev *accel = alt_up_accelerometer_spi_open_dev("/dev/ACCEL_SPI");

  if (!accel) {
	  printf("[ACCEL] Failed to open device.\n");
	  return -1;
  } else {
	  printf("[ACCEL] Device initialized successfully.\n");
  }

  alt_32 x, y, z;

  while(1) {
	  alt_up_accelerometer_spi_read_x_axis(accel, &x);
	  alt_up_accelerometer_spi_read_y_axis(accel, &y);
	  alt_up_accelerometer_spi_read_z_axis(accel, &z);

	  sprintf(output, "[ACCEL] X =%ld, Y =%ld, Z =%ld\n", x, y, z);
	  printf("%s", output);
	  usleep(500000);
  }


  return 0;
}



static void sevenseg_set_hex(int hex, uint32_t segment_base_address)
{
    static alt_u8 segments[16] = {
        0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, // 0-7
        0x80, 0x90, 0x88, 0x83, 0xC6, 0xA1, 0x86, 0x8E  // 8-F
    };                     /* a-f */

    unsigned int data = segments[hex & 15] | (segments[(hex >> 4) & 15] << 8);

    IOWR_ALTERA_AVALON_PIO_DATA(segment_base_address, data);
}

// VGA FUNCTIONS

void write_pixel(unsigned int addr, unsigned char color) {
	//ADDR_EXPORT = addr;
	IOWR_ALTERA_AVALON_PIO_DATA(IMG_ADDR_DRAM_BASE, addr);
	//PIXEL_EXPORT = color & 0xF;
	IOWR_ALTERA_AVALON_PIO_DATA(PIXEL_DATA_BASE, color & 0xF);
	//WREN_EXPORT = 1;
	IOWR_ALTERA_AVALON_PIO_DATA(WRITE_ENABLE_BASE, 0x1);
	//WREN_EXPORT = 0;
	IOWR_ALTERA_AVALON_PIO_DATA(WRITE_ENABLE_BASE, 0x0);

}
void draw_color_stripes() {
	for (int y = 0; y < 240; y++) {
		for (int x = 0; x < 320; x++) {
			unsigned int addr = y * 320 + x;
			unsigned char color = x / 20;
			write_pixel(addr, color);
		}
	}
}
void draw_vertical_stripes() {
	for (int y = 0; y < 240; y++) {
		unsigned char color = y / 15;
		for (int x = 0; x < 320; x++) {
			unsigned int addr = y * 320 + x;
			write_pixel(addr, color);
		}
	}
}
